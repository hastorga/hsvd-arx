Y = load("DataGrupo1.dat");

#Y = [1;2;3;4;5;6;7;8;9;10]; # Data ejeplo easy
n = 10; # niveles de descomposicion
horizonte = 1; #horizonte
h = 3; # lag
hrow = 3; # filas hankel
train = 0.8; # % de entrenamiento
acum = 0;
trainData = Y(1:size(Y,1)*train);
B = Y';
#matrix_80_size = int16(size(B,2)*0.8)+1;
#matrix_content = B(1,matrix_80_size:end);

for i = 1:n
#Se obtienen los valores de alta y baja frecuencia que son retornados por la función hsvd 
[B,A] = hsvd(B,hrow);
acum = acum + A; # Suma de las altas frecuencias
endfor

# Se suman los valores de la componente de alta frecuencia a los de baja frecuencia. 
# X debe ser igual al dataset de entrada.
X = B + acum;

# Se obtienen los valores estimados de las frecuencias mediante la AR
lf = ar(B,h, horizonte);
arx = [B acum];
hf = ar(arx,h, horizonte);

final = hf+lf;
figure(1)
cla()
plot(Y(size(Y,1)-93:end,1))
hold on
plot(final, "r")


real = Y(size(Y,1)-93:end,1);
e = real-final;
err = mean(real-final).^2
rmse = err.^0.5
mae = mean(abs(e))
mape = mean(abs(e./real))
mNSE = 1 - (sum(abs(e))/sum(abs(real.-mean(real)))) 
