# hsvd-arx
ARX using singular value decomposition of hankel matrix
